package com.jancoyan.jancoblog.service;

import com.jancoyan.jancoblog.pojo.Type;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author Jancoyan
 * @since 2021-09-14
 */
public interface TypeService extends IService<Type> {

}
