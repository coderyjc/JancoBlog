package com.jancoyan.jancoblog.service;

import com.jancoyan.jancoblog.pojo.UserLogin;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author Jancoyan
 * @since 2021-10-15
 */
public interface UserLoginService extends IService<UserLogin> {

}
