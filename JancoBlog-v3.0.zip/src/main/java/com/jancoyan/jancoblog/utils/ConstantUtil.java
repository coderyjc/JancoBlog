/**
 * @Author: Yan Jingcun
 * @Date: 2021/10/23
 * @Description:
 * @Version: 1.0
 */

package com.jancoyan.jancoblog.utils;

public class ConstantUtil {

//    public static final String STATIC_RESOURCES =  "C:/Users/Administrator/Pictures/webstatic";
//    public static final String STATIC_URL = "http://localhost:8000";

//    deploy
    public static final String STATIC_RESOURCES =  "/home/jancoyan/springbootApp/blog/static";
    public static final String STATIC_URL = "http://101.201.64.102:8000";

}